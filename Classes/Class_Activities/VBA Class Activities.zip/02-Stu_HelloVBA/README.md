# Hello, VBA

It’s time to write your first VBA script!

## Instructions

* Create and execute a VBA script that generates three pop-up messages containing any text of your choice.

* If you finish early, try to help other students complete the activity.

—
© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
